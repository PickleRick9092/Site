"use client";

import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Play } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const videos = [
  {
    id: "video1",
    title: "Advanced SEO Techniques for 2025",
    thumbnail: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80",
    embedId: "dQw4w9WgXcQ", // YouTube video ID
    duration: "15:24"
  },
  {
    id: "video2",
    title: "Responsive Design Best Practices",
    thumbnail: "https://images.unsplash.com/photo-1551650975-87deedd944c3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80",
    embedId: "dQw4w9WgXcQ", // YouTube video ID
    duration: "12:51"
  },
  {
    id: "video3",
    title: "Web Performance Optimization",
    thumbnail: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80",
    embedId: "dQw4w9WgXcQ", // YouTube video ID
    duration: "18:07"
  }
];

export function VideoSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const videosRef = useRef<HTMLDivElement[]>([]);

  useEffect(() => {
    // Animation for the section title
    gsap.fromTo(
      titleRef.current,
      { y: 50, opacity: 0 },
      {
        y: 0,
        opacity: 1,
        duration: 0.8,
        scrollTrigger: {
          trigger: titleRef.current,
          start: "top 80%",
        },
      }
    );

    // Animation for each video card
    videosRef.current.forEach((video, index) => {
      gsap.fromTo(
        video,
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          delay: 0.2 * index,
          scrollTrigger: {
            trigger: video,
            start: "top 85%",
          },
        }
      );
    });

    return () => {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, []);

  // Function to add videos to the ref array
  const addToRefs = (el: HTMLDivElement) => {
    if (el && !videosRef.current.includes(el)) {
      videosRef.current.push(el);
    }
  };

  return (
    <section id="videos" ref={sectionRef} className="py-24 bg-muted/30">
      <div className="container mx-auto px-4 md:px-6">
        <h2 
          ref={titleRef} 
          className="text-3xl md:text-4xl font-bold text-center mb-16"
        >
          Educational Content
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {videos.map((video, index) => (
            <div
              key={video.id}
              ref={addToRefs}
              className="group relative overflow-hidden rounded-lg bg-card border border-border transition-all duration-300 hover:shadow-lg"
            >
              <div className="relative aspect-video w-full overflow-hidden">
                <img
                  src={video.thumbnail}
                  alt={video.title}
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="rounded-full bg-primary/90 p-3 text-primary-foreground">
                    <Play size={24} fill="currentColor" />
                  </div>
                </div>
                <div className="absolute bottom-2 right-2 bg-black/70 px-2 py-1 text-xs text-white rounded">
                  {video.duration}
                </div>
              </div>
              
              <div className="p-4">
                <h3 className="text-lg font-semibold mb-2 line-clamp-2">{video.title}</h3>
                <a 
                  href={`https://www.youtube.com/watch?v=${video.embedId}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm text-primary hover:underline"
                >
                  Watch on YouTube
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}