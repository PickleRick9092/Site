"use client";

import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { Button } from '@/components/ui/button';
import { ArrowDown } from 'lucide-react';

export function HeroSection() {
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const tl = gsap.timeline({ defaults: { ease: "power3.out" } });
    
    tl.fromTo(titleRef.current, 
      { y: 50, opacity: 0 }, 
      { y: 0, opacity: 1, duration: 1 }
    )
    .fromTo(subtitleRef.current, 
      { y: 20, opacity: 0 }, 
      { y: 0, opacity: 1, duration: 0.8, delay: 0.2 }, 
      "-=0.4"
    )
    .fromTo(ctaRef.current, 
      { y: 20, opacity: 0 }, 
      { y: 0, opacity: 1, duration: 0.8 }, 
      "-=0.4"
    )
    .fromTo(scrollRef.current, 
      { opacity: 0 }, 
      { opacity: 1, duration: 0.8, delay: 0.4 }
    );

    // Animate the scroll indicator
    gsap.to(scrollRef.current, {
      y: 10,
      repeat: -1,
      yoyo: true,
      duration: 1.5,
      ease: "power1.inOut"
    });

    return () => {
      tl.kill();
    };
  }, []);

  const scrollToSkills = () => {
    const skillsSection = document.getElementById('skills');
    if (skillsSection) {
      skillsSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center px-4 md:px-6 py-24 overflow-hidden bg-background">
      <div className="absolute inset-0 z-0 opacity-5">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-secondary/10" />
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />
      </div>
      
      <div className="container max-w-5xl mx-auto z-10 text-center">
        <h1 
          ref={titleRef} 
          className="text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight mb-6"
        >
          John Doe
        </h1>
        <p 
          ref={subtitleRef} 
          className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto mb-10"
        >
          Web Developer & SEO Expert crafting beautiful, high-performing digital experiences
        </p>
        <div ref={ctaRef} className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button size="lg" className="text-base">
            View My Work
          </Button>
          <Button 
            variant="outline" 
            size="lg" 
            className="text-base"
            onClick={scrollToSkills}
          >
            Explore My Skills
          </Button>
        </div>
      </div>
      
      <div 
        ref={scrollRef} 
        className="absolute bottom-10 left-1/2 transform -translate-x-1/2 cursor-pointer"
        onClick={scrollToSkills}
      >
        <ArrowDown className="animate-bounce" size={24} />
      </div>
    </section>
  );
}