"use client";

import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Code, Globe, Search, Palette, Database, LineChart } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const skills = [
  {
    title: "Web Development",
    description: "Building responsive, accessible websites with modern frameworks",
    icon: Code,
  },
  {
    title: "SEO Optimization",
    description: "Improving search visibility and driving organic traffic",
    icon: Search,
  },
  {
    title: "UI/UX Design",
    description: "Creating intuitive, engaging user experiences",
    icon: Palette,
  },
  {
    title: "Web Performance",
    description: "Optimizing load times and core web vitals",
    icon: LineChart,
  },
  {
    title: "Database Design",
    description: "Structuring efficient, scalable data solutions",
    icon: Database,
  },
  {
    title: "Global Reach",
    description: "Developing international, multilingual web solutions",
    icon: Globe,
  }
];

export function SkillsSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const cardsRef = useRef<HTMLDivElement[]>([]);

  useEffect(() => {
    // Animation for the section title
    gsap.fromTo(
      titleRef.current,
      { y: 50, opacity: 0 },
      {
        y: 0,
        opacity: 1,
        duration: 0.8,
        scrollTrigger: {
          trigger: titleRef.current,
          start: "top 80%",
        },
      }
    );

    // Animation for each skill card
    cardsRef.current.forEach((card, index) => {
      gsap.fromTo(
        card,
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          delay: 0.1 * index,
          scrollTrigger: {
            trigger: card,
            start: "top 85%",
          },
        }
      );
    });

    return () => {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, []);

  // Function to add cards to the ref array
  const addToRefs = (el: HTMLDivElement) => {
    if (el && !cardsRef.current.includes(el)) {
      cardsRef.current.push(el);
    }
  };

  return (
    <section id="skills" ref={sectionRef} className="py-24 bg-muted/30">
      <div className="container mx-auto px-4 md:px-6">
        <h2 
          ref={titleRef} 
          className="text-3xl md:text-4xl font-bold text-center mb-16"
        >
          My Expertise
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skills.map((skill, index) => (
            <div
              key={index}
              ref={addToRefs}
              className="bg-card rounded-lg p-6 shadow-sm hover:shadow-md transition-all duration-300 border border-border"
            >
              <div className="flex items-center mb-4">
                <div className="p-3 rounded-md bg-primary/10 text-primary mr-4">
                  <skill.icon size={24} />
                </div>
                <h3 className="text-xl font-semibold">{skill.title}</h3>
              </div>
              <p className="text-muted-foreground">{skill.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}